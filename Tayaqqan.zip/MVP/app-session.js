// app-session.js
const KEY = "TAQQON_DEMO_V1";

export function setSession(data) {
  sessionStorage.setItem(KEY, JSON.stringify(data));
}

export function getSession() {
  try {
    const raw = sessionStorage.getItem(KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function patchSession(partial) {
  const cur = getSession() || {};
  setSession({ ...cur, ...partial });
}

export function clearSession() {
  sessionStorage.removeItem(KEY);
}

export function requireLogin(redirectTo = "login.html") {
  if (sessionStorage.getItem("absher_logged_in") !== "yes") {
    window.location.replace(redirectTo);
  }
}
