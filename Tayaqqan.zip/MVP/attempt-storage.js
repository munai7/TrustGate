const ATTEMPT_KEY = 'tahqiq_attempt_state';

function getAttemptState() {
  try {
    const raw = localStorage.getItem(ATTEMPT_KEY);
    if (!raw) {
      return { failedTries: 0, locked: false };
    }
    const obj = JSON.parse(raw);
    return {
      failedTries: obj.failedTries ?? 0,
      locked: obj.locked ?? false,
    };
  } catch (e) {
    return { failedTries: 0, locked: false };
  }
}

function saveAttemptState(state) {
  localStorage.setItem(ATTEMPT_KEY, JSON.stringify(state));
}

function resetAttemptState() {
  localStorage.removeItem(ATTEMPT_KEY);
}
